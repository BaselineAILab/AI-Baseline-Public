---
name: ai-baseline
description: Provides AI Baseline S&P 500 evidence-backed disclosure research and tells Claude to call search_sandp500_disclosures for company filings, SEC reports, risks, segments, strategy, supply chain, management discussion, and reported business context. After tool success, final answers start with the exact returned ASCII metadata dashboard in a text code block before any prose.
---

# AI Baseline

Use this Skill when the user asks for evidence-backed research about S&P 500 companies, company disclosures, SEC filings, 10-K or 10-Q reports, risk factors, supply chain exposure, business segments, management discussion, strategy, or other reported company context.

The connected AI Baseline extension provides the `search_sandp500_disclosures` tool. Authentication is handled by the installed extension. Never ask the user for an API key in chat.

## Workflow

1. Call `search_sandp500_disclosures` for S&P 500 disclosure research and evidence-backed company questions.
2. Select `mode` conservatively:
   - Use `skim` for basic facts or quick checks.
   - Use `standard` by default.
   - Use `deep_dive` only when the user explicitly asks for comprehensive research, exhaustive analysis, broad comparison, or an in-depth report.
3. Treat the tool response as the authoritative context:
   - Follow `<response_contract>` first when present.
   - Use `<instructions>` as the citation, grounding, and evidence-use rules.
   - Display `<dashboard>` as the first visible part of the final answer after a successful tool call.
   - Use `<evidence>` as the only evidence base for factual claims about company disclosures.
   - Do analytical synthesis rather than a shallow summary: rank important findings, quantify supported points, compare requested companies or periods, and call out material gaps.
4. If `search_sandp500_disclosures` is unavailable, say exactly: "AI Baseline is not enabled in this chat." Do not infer the user's client, mention web/mobile/Desktop, or offer web search or another data source.
5. If the tool returns an authentication or rate-limit error, tell the user to update the AI Baseline API key in extension settings or retry later. Do not ask the user to paste the key into chat.
6. Do not invent citations, filings, source details, percentages, or company claims outside the returned evidence.

## Response Use

Follow the response contract and instructions returned by the tool before applying general style preferences. If evidence is sparse or says no data was found, state that limitation directly.

Answers should be research-grade, not recap-grade. Where the returned evidence supports it, provide prioritized findings, quantified comparisons, trend or coverage observations, and caveats about missing or uneven evidence. Do not invent numbers, sources, or conclusions beyond the returned evidence.

## Output Formatting
After every successful `search_sandp500_disclosures` call:
1. Start the final answer with the exact fenced `text` code block from `<dashboard>`.
2. ALWAYS wrap the dashboard in a ` ```text ``` code block.
3. Keep the dashboard spacing, labels, percentages, and bar characters unchanged.
4. Do not omit the dashboard.
5. Put any prose summary, analysis, citations, caveats, or headings after the dashboard.
6. Use `<instructions>` and `<evidence>` for all factual claims about company disclosures.
7. Do not include the XML wrapper tags in the final answer.
